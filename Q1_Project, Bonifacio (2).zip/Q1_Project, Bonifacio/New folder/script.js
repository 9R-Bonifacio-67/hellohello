function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
    function generateName() {
      const names = [
        "shteppi", "The Beatles (peak)", "Pink Floyd", "ATARASHII GAKKO!", "Netural Milk Hotel", "MF DOOM",
        "Kanye West (not Ye)", "The Notorious B.I.G", "Chopin", "Rachmaninoff", "Oscar Peterson", "Bill Evans",
         "bill wurtz", "New Jeans (hanni!!)", "Nick Drake", "Laufey", "Ginger Root", "Brahms", "Shummann", "Polyphia", "Leopold Auer",
          "Limp Bizkit", "Michael Jackson", "gleamroom", "loser64", "ippo.tsk", "Kazuhito Yamashita", "Nirvana", "Ichika Nito", "Francisco Buencamino", 
          "Baths (bee and puppycat soundtrack)", "Radiohead", "Thelonious Monk", "weezer", "Listz", "Steely Dan", "Paolo Gans", "Horror Skunx (verity)" ] 
          ;

      const index = Math.floor(Math.random() * names.length);
      const name = names[index];

      const nameElement = document.getElementById("name");
      nameElement.innerText = name;
      }
